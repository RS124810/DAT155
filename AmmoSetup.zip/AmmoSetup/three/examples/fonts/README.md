## MgOpen typefaces

# Source and License

https://web.archive.org/web/20050528114140/https://ellak.gr/fonts/mgopen/index.en

# Usage

Use Facetype.js to generate typeface.json fonts: https://gero3.github.io/facetype.js/

Collection of Google fonts as typeface data for usage with three.js: https://github.com/components-ai/typefaces
